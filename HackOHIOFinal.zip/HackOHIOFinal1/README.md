# HackOHI/O Example Application

This is an example application for the HackOHI/O event. You will have access to example applications for both iOS and Android. These examples are meant to give you an idea on how to access the Crown REST endpoints successfully (there will be portions that will need to be implemented by the teams that are not included here), they are not fully functioning applications.

## Installation

XCode and Android Studio were utilized in the development of these applications and can help to better analyze the data from the REST endpoint. You can also utilize tools such as Postman to hit the REST endpoints.

## Operation
1) Using an HTTP POST request a JWT token is acquired.
2) Using the JWT toke from step 1, an HTTP GET request is sent to retrieve required data from the REST endpoint.

## Further Reading
- https://jwt.io/ (JSON Web Tokens)
- https://square.github.io/retrofit/ (REST API Endpoint Library for Java or Kotlin)

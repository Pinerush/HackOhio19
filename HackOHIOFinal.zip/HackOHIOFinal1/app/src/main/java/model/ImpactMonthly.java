package model;

import com.google.gson.annotations.SerializedName;

public class ImpactMonthly {

    @SerializedName("impactCount")
    private Integer impactCount;

    @SerializedName("month")
    private Integer month;

    @SerializedName("year")
    private Integer year;

    public ImpactMonthly(Integer impactCount, Integer month, Integer year) {
        this.impactCount = impactCount;
        this.month = month;
        this.year = year;
    }

    public Integer getImpactCount() { return impactCount; }
    public Integer getMonth()       { return month; }
    public Integer getYear()        { return year; }

}
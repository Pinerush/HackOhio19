package model;

import com.google.gson.annotations.SerializedName;

public class AuthCredentials
{
    @SerializedName("password")
    String password;

    @SerializedName("username")
    String username;

    public AuthCredentials(String password, String username)
    {
        this.password = password;
        this.username = username;
    }
}
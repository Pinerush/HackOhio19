package model;

import com.google.gson.annotations.SerializedName;

public class AuthResponse
{
    @SerializedName("token")
    String token;

    public AuthResponse(String token)
    {
        this.token = token;
    }

    public String getToken()
    {
        return token;
    }

}
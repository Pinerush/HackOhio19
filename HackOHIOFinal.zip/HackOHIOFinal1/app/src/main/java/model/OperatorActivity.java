package model;

import com.google.gson.annotations.SerializedName;

public class OperatorActivity {

    @SerializedName("firstName")
    private String firstName;

    @SerializedName("lastName")
    private String lastName;

    @SerializedName("activity")
    private String activity;
    @SerializedName("middleName")
    private String middleName;

    @SerializedName("totalActivityTime")
    private Integer totalActivityTime;

    @SerializedName("totalLogOnTime")
    private Integer totalLogOnTime;

    @SerializedName("userId")
    private Integer userId;

    public OperatorActivity(String activity, String firstName, String lastName, String middleName, Integer totalActivityTime, Integer totalLogOnTime, Integer userId) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.middleName = middleName;
        this.totalActivityTime = totalActivityTime;
        this.totalLogOnTime = totalLogOnTime;
        this.userId = userId;
        this.activity = activity;
    }

    public String getfirstName(){return firstName;}
    public String getlastName(){return lastName;}
    public String getmiddleName(){return middleName;}
    public Integer gettotalActivityTime(){return totalActivityTime;}
    public Integer getTotalLogOnTime(){return totalLogOnTime;}
    public Integer getUserId(){return userId;}
    public String getActivity() {return activity;}
}
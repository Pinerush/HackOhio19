package model;

import com.google.gson.annotations.SerializedName;

public class ImpactOperator {

    @SerializedName("employeeNum")
    private String employeeNum;

    @SerializedName("firstName")
    private String firstName;

    @SerializedName("impactCount")
    private Integer impactCount;

    @SerializedName("lastName")
    private String lastName;

    @SerializedName("middleName")
    private String middleName;

    @SerializedName("userId")
    private Integer userId;

    public ImpactOperator(String employeeNum, String firstName, Integer impactCount, String lastName, String middleName, Integer userId) {
        this.employeeNum = employeeNum;
        this.firstName = firstName;
        this.impactCount = impactCount;
        this.lastName = lastName;
        this.middleName = middleName;
        this.userId = userId;
    }

    public String getEmployeeNum(){return employeeNum;}
    public String getFirstName(){return firstName;}
    public Integer getImpactCount(){return impactCount;}
    public String getLastName(){return lastName;}
    public String getMiddleName(){return middleName;}
    public Integer getUserId(){return userId;}
}
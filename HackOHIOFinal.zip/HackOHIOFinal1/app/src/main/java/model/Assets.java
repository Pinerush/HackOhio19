package model;

import com.google.gson.annotations.SerializedName;

public class Assets {


    @SerializedName("equipmentId")
    private Integer equipmentId;
    @SerializedName("userId")
    private Integer userId;
    @SerializedName ("serialNumber")
    private String serialNumber;
    @SerializedName ("lastName")
    private String lastName;


    public Assets(Integer equipmentId, String employeeNumber, String equipmentRoleName, String lastName) {
        this.equipmentId = equipmentId;
        this.userId = userId;
        this.serialNumber = serialNumber;
        this.lastName = lastName;
    }

    public Integer getequipmentId() { return equipmentId; }
    public Integer getuserId()       { return userId; }
    public String getserialNumber()        { return serialNumber; }
    public String getlastName()             {return lastName; }


}

package model;

import com.google.gson.annotations.SerializedName;

public class AssetStatus {

    @SerializedName("serialNumber")
    private String serialNumber;

    @SerializedName("equipmentId")
    private Integer equipmentId;

    @SerializedName("utilizationStatus")
    private String utilizationStatus;

   // @SerializedName("impactCount")
   // private Integer impactCount;

   // @SerializedName("lastName")
   // private String lastName;

   // @SerializedName("middleName")
   // private String middleName;

   // @SerializedName("userId")
   // private Integer userId;

    public AssetStatus(String utilizationStatus, Integer equipmentId, String serialNumber) {
        this.equipmentId = equipmentId;
        this.serialNumber = serialNumber;
        this.utilizationStatus = utilizationStatus;
    }

    public Integer getequipmentId(){return equipmentId;}
    public String getserialNumber(){return serialNumber;}
    public String getutilizationStatus() {return utilizationStatus;}
}
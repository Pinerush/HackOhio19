package network;

import java.util.List;
import model.ImpactMonthly;
import model.ImpactOperator;
import model.AuthCredentials;
import model.AuthResponse;
import model.AssetStatus;
import model.OperatorActivity;
import model.Assets;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface RestApiInterface {

    @Headers({"Content-Type: application/json"})
    @GET("/api/impact-meter-app/v1/impacts/month")
    Call<List<ImpactMonthly>> getImpactCount(@Header("Authorization") String bearerToken, @Query("months") Integer numMonths);

    @Headers({"Content-Type: application/json"})
    @GET("/api/impact-meter-app/v1/impacts/operators")
    Call<List<ImpactOperator>> getImpactOperators(@Header("Authorization") String bearerToken, @Query("startDate") String startDate);

    @Headers({"Content-Type: application/json"})
    @POST("/api/authentication/v1/login")
    Call<AuthResponse> getAuthToken(@Body AuthCredentials AuthCredentials);

    @Headers({"Content-Type: application/json"})
    @GET("/api/assets-app/v2/equipment")
    Call<List<Assets>> getAssets(@Header("Authorization") String bearerToken);

    @Headers({"Content-Type: application/json"})
    @GET("/api/utilization-app/v1/equipment/current-available-detail")
    Call<List<AssetStatus>> getAssetStatus(@Header("Authorization") String bearerToken);


    @Headers({"Content-Type: application/json"})
    @GET("/api/productivity-app/v1/reports/operator-activity")
    Call<List<OperatorActivity>> getOperatorActivity(@Header("Authorization") String bearerToken, @Query("includeNoShiftId") String includeNoShiftId);



}
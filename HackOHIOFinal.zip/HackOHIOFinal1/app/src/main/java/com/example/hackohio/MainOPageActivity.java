package com.example.hackohio;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;
import model.ImpactMonthly;
import model.ImpactOperator;
import model.AuthCredentials;
import model.AuthResponse;
import model.Assets;
import network.RestApiInterface;
import network.RetrofitClientInstance;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainOPageActivity extends AppCompatActivity {
    public static String authToken = "";
    RestApiInterface ApiService;
    private Button seeRank;
    private Button reportMalfunction;
    private Button reportNearMiss;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainopage);
        ApiService = RetrofitClientInstance.getRetrofitInstance().create(RestApiInterface.class);

        /**
         * Enqueue an authentication call to the REST API endpoint.  Note that
         * embedding credentials in source code is *generally* bad practice ;)
         *
         * This inline class will return a JSON Web Token (JWT) authentication
         * token into `authToken`
         */



        Call<AuthResponse> authCall = ApiService.getAuthToken(new AuthCredentials(loginActivity2.CloudPin, loginActivity2.CloudUsername));
        authCall.enqueue((new Callback<AuthResponse>() {
            @Override
            public void onResponse(Call<AuthResponse> call, Response<AuthResponse> response) {
                /* Extract auth token if available, otherwise notify user. */
                if (null != response.body())
                {
                    Toast.makeText(MainOPageActivity.this, "REST API authentication successful.", Toast.LENGTH_SHORT).show();
                    authToken = response.body().getToken();
                }
                else {
                    Toast.makeText(MainOPageActivity.this, "REST API authentication failed.", Toast.LENGTH_SHORT).show();
                    authToken = "";
                }
            }

            @Override
            public void onFailure(Call<AuthResponse> call, Throwable t) {
                Toast.makeText(MainOPageActivity.this, "REST API authentication failed.", Toast.LENGTH_SHORT).show();
            }
        }));


        seeRank=(Button)findViewById(R.id.Rank_button);
        seeRank.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //openRankActivity();
            }
        });

        /*operator button*/
        reportMalfunction=(Button)findViewById(R.id.reportMalfunctions_button);
        reportMalfunction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMalfunctionActivity();
            }
        });


        /*pedestrian button*/
        reportNearMiss=(Button)findViewById(R.id.near_miss_button);
        reportNearMiss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMalfunctionActivity();
            }
        });

    }
    public void openRankActivity(){

        Intent intent = new Intent(this,RankActivity.class);
        startActivity(intent);

    }
    public void openMalfunctionActivity(){

        Intent intent = new Intent(this,MalfunctionActivity.class);
        startActivity(intent);
    }
    public void openNear_Miss_Activity(){

        Intent intent = new Intent(this,Near_Miss_Activity.class);
        startActivity(intent);
    }



}





















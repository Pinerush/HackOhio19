package com.example.hackohio;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;
import model.ImpactMonthly;
import model.OperatorActivity;
import model.ImpactOperator;
import model.AuthCredentials;
import model.AuthResponse;
import model.AssetStatus;
import model.Assets;
import network.RestApiInterface;
import network.RetrofitClientInstance;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProductivityActivity extends AppCompatActivity {
    String authToken = "";
    private Button viewAlloperatorButton;
    private Button viewAlltruckButton;
    private Button mostProductiveOperatorButton;
    private Button mostProductiveTruckButton;
    RestApiInterface ApiService;


    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_productivity);
        ApiService = RetrofitClientInstance.getRetrofitInstance().create(RestApiInterface.class);


        viewAlloperatorButton = (Button) findViewById(R.id.all_Operators_button);
        viewAlloperatorButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if ("" != MainSPageActivity.authToken) {
                    Call<List<OperatorActivity>> operatorActivityCall = ApiService.getOperatorActivity("Bearer:" + (MainSPageActivity.authToken), "True");

                    operatorActivityCall.enqueue(new Callback<List<OperatorActivity>>() {
                        @Override
                        public void onResponse(Call<List<OperatorActivity>> call, Response<List<OperatorActivity>> response) {
                            TextView myTextView = findViewById(R.id.myTextView);
                            if (null != response.body()) {

                                myTextView.setText("");
                                for (OperatorActivity entry : response.body()) {
                                    myTextView.append("Activities:" + entry.getActivity() + "\n");
                                    myTextView.append("First Name: " + entry.getfirstName() + "\n");
                                    // myTextView.append("Equipment Status: " + entry.getutilizationStatus() + "\n");
                                    myTextView.append("Last Name: " + entry.getlastName() + "\n\n");

                                }
                            } else {
                                Toast.makeText(ProductivityActivity.this, "Data fetch failed.", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<List<OperatorActivity>> call, Throwable t) {
                            Toast.makeText(ProductivityActivity.this, "Data fetch failed.", Toast.LENGTH_SHORT).show();
                        }
                    });
                } else {
                    Toast.makeText(ProductivityActivity.this, "Not authorized to access REST API endpoint.", Toast.LENGTH_SHORT).show();
                }


            }
        });

        viewAlltruckButton = (Button) findViewById(R.id.all_Trucks_button);
        viewAlloperatorButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Toast.makeText(ProductivityActivity.this, "Coming Soon", Toast.LENGTH_SHORT).show();

            }
        });

        mostProductiveOperatorButton = (Button) findViewById(R.id.mostProductive_Truck_button);
        mostProductiveOperatorButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Toast.makeText(ProductivityActivity.this, "Coming Soon", Toast.LENGTH_SHORT).show();

            }
        });

        mostProductiveTruckButton = (Button) findViewById(R.id.mostProductive_Truck_button);
        mostProductiveTruckButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Toast.makeText(ProductivityActivity.this, "Coming Soon", Toast.LENGTH_SHORT).show();

            }
        });


    }
}





















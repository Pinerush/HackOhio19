package com.example.hackohio;

import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;
import model.ImpactMonthly;
import model.ImpactOperator;
import model.AuthCredentials;
import model.AuthResponse;
import model.Assets;
import network.RestApiInterface;
import network.RetrofitClientInstance;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    ProgressDialog progressDialog;
    RestApiInterface ApiService;
    String authToken = "";
    String LoginId = "";
    private Button supervisorB;
    private Button operatorB;
    private Button pedestrianB;
    Animation frombottom;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*operator button*/
        supervisorB=(Button)findViewById(R.id.loginBtn);
        frombottom= AnimationUtils.loadAnimation(this,R.anim.frombottom);
        supervisorB.setAnimation(frombottom);
        supervisorB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openloginActivity();
            }
        });

        /*operator button*/
        operatorB=(Button)findViewById(R.id.loginBtn2);
        operatorB.setAnimation(frombottom);
        operatorB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openloginActivity2();
            }
        });


        /*pedestrian button*/
        pedestrianB=(Button)findViewById(R.id.loginBtn3);
        pedestrianB.setAnimation(frombottom);
        pedestrianB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openloginActivity3();
            }
        });



    }

    public void openloginActivity(){

        Intent intent = new Intent(this,loginActivity.class);
        startActivity(intent);

    }
    public void openloginActivity2(){

        Intent intent = new Intent(this,loginActivity2.class);
        startActivity(intent);
    }
    public void openloginActivity3(){

        Intent intent = new Intent(this,MalfunctionActivity.class);
        startActivity(intent);
    }
}
package com.example.hackohio;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;
import model.ImpactMonthly;
import model.ImpactOperator;
import model.AuthCredentials;
import model.AuthResponse;
import model.Assets;
import network.RestApiInterface;
import network.RetrofitClientInstance;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainSPageActivity extends AppCompatActivity {
    public static String authToken = "";
    RestApiInterface ApiService;
    private Button assetButton;
    private Button collisionButton;
    private Button securityButton;
    private Button productivityButton;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainspage);
        ApiService = RetrofitClientInstance.getRetrofitInstance().create(RestApiInterface.class);

        /**
         * Enqueue an authentication call to the REST API endpoint.  Note that
         * embedding credentials in source code is *generally* bad practice ;)
         *
         * This inline class will return a JSON Web Token (JWT) authentication
         * token into `authToken`
         */



           Call<AuthResponse> authCall = ApiService.getAuthToken(new AuthCredentials(loginActivity.CloudPin, loginActivity.CloudUsername));
          authCall.enqueue((new Callback<AuthResponse>() {
            @Override
          public void onResponse(Call<AuthResponse> call, Response<AuthResponse> response) {
        /* Extract auth token if available, otherwise notify user. */
              if (null != response.body())
             {
                Toast.makeText(MainSPageActivity.this, "REST API authentication successful.", Toast.LENGTH_SHORT).show();
                authToken = response.body().getToken();
            }
           else {
               Toast.makeText(MainSPageActivity.this, "REST API authentication failed.", Toast.LENGTH_SHORT).show();
               authToken = "";
           }
         }

         @Override
           public void onFailure(Call<AuthResponse> call, Throwable t) {
               Toast.makeText(MainSPageActivity.this, "REST API authentication failed.", Toast.LENGTH_SHORT).show();
             }
           }));


        assetButton=(Button)findViewById(R.id.asset_button);
        assetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAssetActivity();
            }
        });

        /*operator button*/
        collisionButton=(Button)findViewById(R.id.collision_button);
        collisionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCollisionActivity();
            }
        });


        /*pedestrian button*/
        securityButton=(Button)findViewById(R.id.security_button);
        securityButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSecurityActivity();
            }
        });

        productivityButton=(Button)findViewById(R.id.productivity_button);
        productivityButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openProductivityActivity();
            }
        });

    }
    public void openAssetActivity(){

        Intent intent = new Intent(this,AssetActivity.class);
        startActivity(intent);

    }
    public void openCollisionActivity(){

        Intent intent = new Intent(this,CollisionActivity.class);
        startActivity(intent);
    }
    public void openSecurityActivity(){

        Intent intent = new Intent(this,SecurityActivity.class);
        startActivity(intent);
    }

    public void openProductivityActivity(){

        Intent intent = new Intent(this,ProductivityActivity.class);
        startActivity(intent);
    }

}





















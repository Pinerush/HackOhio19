package com.example.hackohio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class loginActivity2 extends AppCompatActivity
{
    private Button enter;
    private EditText username;
    private EditText pin;
    private EditText cloudUser;
    private EditText cloudPassword;
    public static String CloudUsername;
    public static String CloudPin;
    public static String LoginId;
    public static String LoginPin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login2);
        enter=(Button)findViewById(R.id.loginBtn3);
        username=(EditText)findViewById(R.id.login_mail);
        pin=(EditText)findViewById(R.id.pin);
        enter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoginId = username.getText().toString();
                LoginPin = pin.getText().toString();
                CloudUsername = "hackohio@example.com";
                CloudPin = "Hackohio1!";

                if((LoginId.equals("Truck") && (LoginPin.equals("Operator")))) {

                    showtoast("Login Successful");


                    if((CloudUsername.equals("hackohio@example.com")) && ((CloudPin.equals("Hackohio1!")))) {
                        showtoast("Connected to Cloud");
                        openMainOPage();
                    }

                }
                else {
                    showtoast("incorrect login");
                }
                if((CloudUsername.equals("hackohio@example.com")) && ((CloudPin.equals("Hackohio1!")))) {
                    showtoast("Connected to Cloud");

                }
                else{
                    showtoast("Cloud Connection Failed");
                }
            }

        });



    }
    private void showtoast(String text) {
        Toast.makeText( loginActivity2.this,text, Toast.LENGTH_SHORT).show();
    }


    public void openMainOPage(){

        Intent intent = new Intent(this,MainOPageActivity.class);
        startActivity(intent);

    }


}

package com.example.hackohio;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;
import model.ImpactMonthly;
import model.ImpactOperator;
import model.AuthCredentials;
import model.AuthResponse;
import model.Assets;
import network.RestApiInterface;
import network.RetrofitClientInstance;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MalfunctionActivity extends AppCompatActivity {
    public static String authToken = "";
    RestApiInterface ApiService;
    private Button sendMalfunctionButton;
    private EditText truckID;
    private EditText description;
    private EditText action;
    private String name;


    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_malfunction);
        ApiService = RetrofitClientInstance.getRetrofitInstance().create(RestApiInterface.class);



        name=loginActivity2.LoginId;
        truckID=(EditText)findViewById(R.id.TruckID);
        description=(EditText)findViewById(R.id.description);
        action=(EditText)findViewById(R.id.action);




        /*operator button*/
        sendMalfunctionButton = (Button) findViewById(R.id.SendmalfunctionButton);
        sendMalfunctionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String sendScript = ("Last Name;   " + name + "  " + "Truck ID;  " + (truckID.getText().toString()) + "  "+ "Description;  " + (description.getText().toString()) + "  " + "Action;  " + (action.getText().toString()));




            }
        });


        /*pedestrian button*/


    }
}





















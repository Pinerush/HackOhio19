package com.example.hackohio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class loginActivity extends AppCompatActivity
{
    private Button enter;
    private EditText username;
    private EditText pin;
    private EditText cloudUser;
    private EditText cloudPassword;
    public static String CloudUsername;
    public static String CloudPin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        enter=(Button)findViewById(R.id.loginBtn3);
        username=(EditText)findViewById(R.id.login_mail);
        pin=(EditText)findViewById(R.id.pin);
        cloudUser=(EditText)findViewById(R.id.cloudId);
        cloudPassword=(EditText)findViewById(R.id.cloudPass);
        enter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String LoginId = username.getText().toString();
                String LoginPin = pin.getText().toString();
                CloudUsername = cloudUser.getText().toString();
                CloudPin = cloudPassword.getText().toString();

                if((LoginId.equals("Siefring") && (LoginPin.equals("Mark")))) {

                    showtoast("Login Successful");


                    if((CloudUsername.equals("hackohio@example.com")) && ((CloudPin.equals("Hackohio1!")))) {
                        showtoast("Connected to Cloud");
                        openMainSPage();
                    }

                }
                else {
                    showtoast("incorrect login");
                }
                if((CloudUsername.equals("hackohio@example.com")) && ((CloudPin.equals("Hackohio1!")))) {
                    showtoast("Connected to Cloud");

                }
                else{
                    showtoast("Cloud Connection Failed");
                }
            }

        });



    }
private void showtoast(String text) {
        Toast.makeText( loginActivity.this,text, Toast.LENGTH_SHORT).show();
}


    public void openMainSPage(){

        Intent intent = new Intent(this,MainSPageActivity.class);
        startActivity(intent);

    }


}

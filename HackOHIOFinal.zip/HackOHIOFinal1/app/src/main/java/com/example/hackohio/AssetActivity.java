package com.example.hackohio;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;
import model.ImpactMonthly;
import model.ImpactOperator;
import model.AuthCredentials;
import model.AuthResponse;
import model.AssetStatus;
import model.Assets;
import network.RestApiInterface;
import network.RetrofitClientInstance;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AssetActivity extends AppCompatActivity {
    String authToken = "";
    private Button availableButton;
    private Button loggedInButton;
    private Button notAvailableButton;
    private Button notCommunicatingButton;
    RestApiInterface ApiService;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_asset);
        ApiService = RetrofitClientInstance.getRetrofitInstance().create(RestApiInterface.class);



        availableButton=(Button)findViewById(R.id.available_button);
        availableButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ("" != MainSPageActivity.authToken)
                {
                    Call<List<AssetStatus>> assetStatusCall = ApiService.getAssetStatus("Bearer:"+(MainSPageActivity.authToken));

                    assetStatusCall.enqueue(new Callback<List<AssetStatus>>() {
                        @Override
                        public void onResponse(Call<List<AssetStatus>> call, Response<List<AssetStatus>> response) {
                            TextView myTextView = findViewById(R.id.myTextView);
                            if (null != response.body())
                            {

                                myTextView.setText("");
                                for (AssetStatus entry : response.body()) {
                                    if (entry.getutilizationStatus().equals("AVAILABLE")) {
                                        myTextView.append("EquipmentId: " + entry.getequipmentId() + "\n");
                                        // myTextView.append("Equipment Status: " + entry.getutilizationStatus() + "\n");
                                        myTextView.append("Serial Number: " + entry.getserialNumber() + "\n\n");
                                    }
                                    else {
                                        Toast.makeText(AssetActivity.this, "No Data Satisfies the Criteria", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }
                            else {
                                Toast.makeText(AssetActivity.this, "Data fetch failed.", Toast.LENGTH_SHORT).show();
                            }
                        }
                        @Override
                        public void onFailure(Call<List<AssetStatus>> call, Throwable t) {
                            Toast.makeText(AssetActivity.this, "Data fetch failed.", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
                else
                {
                    Toast.makeText(AssetActivity.this, "Not authorized to access REST API endpoint.", Toast.LENGTH_SHORT).show();
                }




            }
        });

        loggedInButton=(Button)findViewById(R.id.loggedIn_button);
        loggedInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ("" != MainSPageActivity.authToken)
                {
                    Call<List<AssetStatus>> assetStatusCall = ApiService.getAssetStatus("Bearer:"+(MainSPageActivity.authToken));

                    assetStatusCall.enqueue(new Callback<List<AssetStatus>>() {
                        @Override
                        public void onResponse(Call<List<AssetStatus>> call, Response<List<AssetStatus>> response) {
                            TextView myTextView = findViewById(R.id.myTextView);
                            if (null != response.body())
                            {

                                myTextView.setText("");
                                for (AssetStatus entry : response.body()) {
                                    if (entry.getutilizationStatus().equals("LOGGED_IN")) {
                                        myTextView.append("EquipmentId: " + entry.getequipmentId() + "\n");
                                        // myTextView.append("Equipment Status: " + entry.getutilizationStatus() + "\n");
                                        myTextView.append("Serial Number: " + entry.getserialNumber() + "\n\n");
                                    }
                                    else {
                                        Toast.makeText(AssetActivity.this, "No Data Satisfies the Criteria", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }
                            else {
                                Toast.makeText(AssetActivity.this, "Data fetch failed.", Toast.LENGTH_SHORT).show();
                            }
                        }
                        @Override
                        public void onFailure(Call<List<AssetStatus>> call, Throwable t) {
                            Toast.makeText(AssetActivity.this, "Data fetch failed.", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
                else
                {
                    Toast.makeText(AssetActivity.this, "Not authorized to access REST API endpoint.", Toast.LENGTH_SHORT).show();
                }


            }
        });

        notAvailableButton=(Button)findViewById(R.id.notAvailable_button);
        notAvailableButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ("" != MainSPageActivity.authToken)
                {
                    Call<List<AssetStatus>> assetStatusCall = ApiService.getAssetStatus("Bearer:"+(MainSPageActivity.authToken));

                    assetStatusCall.enqueue(new Callback<List<AssetStatus>>() {
                        @Override
                        public void onResponse(Call<List<AssetStatus>> call, Response<List<AssetStatus>> response) {
                            TextView myTextView = findViewById(R.id.myTextView);
                            if (null != response.body())
                            {

                                myTextView.setText("");
                                for (AssetStatus entry : response.body()) {
                                    if (entry.getutilizationStatus().equals("NOT_AVAILABLE")) {
                                        myTextView.append("EquipmentId: " + entry.getequipmentId() + "\n");
                                        // myTextView.append("Equipment Status: " + entry.getutilizationStatus() + "\n");
                                        myTextView.append("Serial Number: " + entry.getserialNumber() + "\n\n");
                                    }
                                    else {
                                        Toast.makeText(AssetActivity.this, "No Data Satisfies the Criteria", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }
                            else {
                                Toast.makeText(AssetActivity.this, "Data fetch failed.", Toast.LENGTH_SHORT).show();
                            }
                        }
                        @Override
                        public void onFailure(Call<List<AssetStatus>> call, Throwable t) {
                            Toast.makeText(AssetActivity.this, "Data fetch failed.", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
                else
                {
                    Toast.makeText(AssetActivity.this, "Not authorized to access REST API endpoint.", Toast.LENGTH_SHORT).show();
                }

            }
        });


        /*pedestrian button*/
        notCommunicatingButton=(Button)findViewById(R.id.notCommunicating_button);
        notCommunicatingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ("" != MainSPageActivity.authToken)
                {
                    Call<List<AssetStatus>> assetStatusCall = ApiService.getAssetStatus("Bearer:"+(MainSPageActivity.authToken));

                    assetStatusCall.enqueue(new Callback<List<AssetStatus>>() {
                        @Override
                        public void onResponse(Call<List<AssetStatus>> call, Response<List<AssetStatus>> response) {
                            TextView myTextView = findViewById(R.id.myTextView);
                            if (null != response.body())
                            {

                                myTextView.setText("");
                                for (AssetStatus entry : response.body()) {
                                    if (entry.getutilizationStatus().equals("NOT_COMMUNICATING")) {
                                        myTextView.append("EquipmentId: " + entry.getequipmentId() + "\n");
                                        // myTextView.append("Equipment Status: " + entry.getutilizationStatus() + "\n");
                                        myTextView.append("Serial Number: " + entry.getserialNumber() + "\n\n");
                                    }
                                }
                            }
                            else {
                                Toast.makeText(AssetActivity.this, "Data fetch failed.", Toast.LENGTH_SHORT).show();
                            }
                        }
                        @Override
                        public void onFailure(Call<List<AssetStatus>> call, Throwable t) {
                            Toast.makeText(AssetActivity.this, "Data fetch failed.", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
                else
                {
                    Toast.makeText(AssetActivity.this, "Not authorized to access REST API endpoint.", Toast.LENGTH_SHORT).show();
                }

            }
        });






    }


}





















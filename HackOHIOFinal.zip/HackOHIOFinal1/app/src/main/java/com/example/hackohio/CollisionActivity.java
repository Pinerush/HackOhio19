package com.example.hackohio;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;
import model.ImpactMonthly;
import model.ImpactOperator;
import model.AuthCredentials;
import model.AuthResponse;
import model.AssetStatus;
import model.Assets;
import network.RestApiInterface;
import network.RetrofitClientInstance;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CollisionActivity extends AppCompatActivity {
    String authToken = "";
    private Button impactMonthlyButton;
    private Button impactOperatorButton;
    RestApiInterface ApiService;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_collision);
        ApiService = RetrofitClientInstance.getRetrofitInstance().create(RestApiInterface.class);



        impactMonthlyButton=(Button)findViewById(R.id.monthlyimpact_button);
        impactMonthlyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ("" != MainSPageActivity.authToken) {
                    Call<List<ImpactMonthly>> impactMonthlyCall = ApiService.getImpactCount("Bearer:" + (MainSPageActivity.authToken), 12);

                    impactMonthlyCall.enqueue(new Callback<List<ImpactMonthly>>() {
                        @Override
                        public void onResponse(Call<List<ImpactMonthly>> call, Response<List<ImpactMonthly>> response) {
                            TextView myTextView = findViewById(R.id.myTextView);
                            if (null != response.body()) {
                                myTextView.setText("");
                                for (ImpactMonthly entry : response.body()) {
                                    myTextView.append("impactCount: " + entry.getImpactCount() + "\n");
                                    myTextView.append("month: " + entry.getMonth() + "\n");
                                    myTextView.append("year: " + entry.getYear() + "\n\n");
                                }
                            } else {
                                Toast.makeText(CollisionActivity.this, "Data fetch failed.", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<List<ImpactMonthly>> call, Throwable t) {
                            Toast.makeText(CollisionActivity.this, "Data fetch failed.", Toast.LENGTH_SHORT).show();
                        }
                    });
                } else {
                    Toast.makeText(CollisionActivity.this, "Not authorized to access REST API endpoint.", Toast.LENGTH_SHORT).show();
                }
            }
        });



        impactOperatorButton=(Button)findViewById(R.id.operatorimpact_button);
        impactOperatorButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
          if ("" != MainSPageActivity.authToken)
            {
                Call<List<ImpactOperator>> impactOperatorCall = ApiService.getImpactOperators("Bearer:"+(MainSPageActivity.authToken), "2019-04-30");

                impactOperatorCall.enqueue(new Callback<List<ImpactOperator>>() {
                    @Override
                    public void onResponse(Call<List<ImpactOperator>> call, Response<List<ImpactOperator>> response) {
                        TextView myTextView = findViewById(R.id.myTextView);
                        if (null != response.body())
                        {
                            myTextView.setText("");
                            for (ImpactOperator entry : response.body())
                            {
                                myTextView.append("Employee Number: " + entry.getEmployeeNum() + "\n");
                                myTextView.append("Employee Name: " + entry.getFirstName() + " " + entry.getLastName() + "\n");
                                myTextView.append("Number of impacts: " + entry.getImpactCount() + "\n");
                                myTextView.append("User ID: " + entry.getUserId() + "\n\n");
                            }
                        }
                        else {
                            Toast.makeText(CollisionActivity.this, "Data fetch failed.", Toast.LENGTH_SHORT).show();
                        }
                    }
                    @Override
                    public void onFailure(Call<List<ImpactOperator>> call, Throwable t) {

                        Toast.makeText(CollisionActivity.this, "Data fetch failed.", Toast.LENGTH_SHORT).show();
                    }
                });
            }
                else
            {
                Toast.makeText(CollisionActivity.this, "Not authorized to access REST API endpoint.", Toast.LENGTH_SHORT).show();
            }


            }
        });




    }


}





















package com.example.hackohio;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;
import model.ImpactMonthly;
import model.OperatorActivity;
import model.ImpactOperator;
import model.AuthCredentials;
import model.AuthResponse;
import model.AssetStatus;
import model.Assets;
import network.RestApiInterface;
import network.RetrofitClientInstance;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SecurityActivity extends AppCompatActivity {
    String authToken = "";
    private Button viewAlloperatorButton;
    private Button viewAlltruckButton;
    private Button mostProductiveOperatorButton;
    private Button mostProductiveTruckButton;
    RestApiInterface ApiService;


    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_security);
        ApiService = RetrofitClientInstance.getRetrofitInstance().create(RestApiInterface.class);

    }}

